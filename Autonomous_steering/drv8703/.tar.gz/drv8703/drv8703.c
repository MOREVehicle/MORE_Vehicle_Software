/**
 * @file drv8703.c
 * @brief Source file for DRV8703 driver functions
 * Handles SPI communication and driver configuration.
 */

#include "drv8703.h"
// #include <spi.h> check correct include for read write
// functions to shutup errors for now
bool HAL_SPI_Transmit(const char* s, uint8_t* dat, uint8_t siz, uint8_t timeout) {return 1;}
bool HAL_SPI_Receive(const char* s, uint8_t* dat, uint8_t siz, uint8_t timeout) {return 1;}
#define HAL_OK 1

/**
 * @brief Initializes the DRV8703 driver.
 * Configures the SPI interface and initializes required settings.
 * @return true if initialization is successful, false otherwise.
 */
void DRV_init(void) {
    DRV_write(DRV_IDRIVE_WD, DRV_IDRIVE_WD_WD_EN_MASK | DRV_IDRIVE_WD_WD_DLY_MASK(0b11));
    DRV_write(DRV_VDS, DRV_VDS_VDS_MASK(0b101) | DRV_VDS_DIS_L2_VDS_MASK);
    DRV_write(DRV_CONFIG, DRV_CONFIG_VREF_SCL_MASK(0b10));
}

/**
 * @brief Writes data to a specific register in the DRV8703 driver.
 * @param address 4-bit register address.
 * @param data 8-bit data to be written.
 * @return true if write operation is successful, false otherwise.
 */
bool DRV_write(uint8_t address, uint8_t data) {
    uint16_t message = 0;
    bool success = true;

    if (address > 0x0F) success = false;
    else {
        message |= DRV_ADDR_MASK(address) | data;
        if (HAL_SPI_Transmit(DRV_SPI_INTERFACE, (uint8_t*)&message, 1, DRV_SPI_TIMEOUT) != HAL_OK) {
            success = false;
        }
    }

    return success;
}

/**
 * @brief Reads data from a specific register in the DRV8703 driver.
 * @param address 4-bit register address.
 * @param data Pointer to store the read 8-bit data.
 * @return true if read operation is successful, false otherwise.
 */
bool DRV_read(uint8_t address, uint8_t* data) {
    uint16_t message = DRV_READWRITE_MASK;
    bool success = true;

    if (address > 0x0F) success = false;
    else {
        message |= DRV_ADDR_MASK(address);
        if (HAL_SPI_Transmit(DRV_SPI_INTERFACE, (uint8_t*)&message, 1, DRV_SPI_TIMEOUT) != HAL_OK) {
            success = false;
        }
        if (HAL_SPI_Receive(DRV_SPI_INTERFACE, data, 1, DRV_SPI_TIMEOUT) != HAL_OK) {
            success = false;
        }
    }

    return success;
}

/**
 * @brief Writes data to multiple registers in the DRV8703 driver.
 * @param data Pointer to an array containing data for registers.
 * @param filter Bit mask to filter out specific registers.
 * @return true if write operation is successful, false otherwise.
 */
bool DRV_writeRegister(uint8_t* data, uint8_t filter) {
    bool success = true;

    for (int i = 0; i < DRV_REG_MAP_SIZE + 1; i++) {
        if (!(filter & (1<<(DRV_REG_MAP_SIZE-i)))) {
            success = DRV_write(DRV_REG_MAP_SIZE-i, data[i]);
            if (!success) break;
        }
    }

    return success;
}

/**
 * @brief Reads data from all registers in the DRV8703 driver.
 * @param data Pointer to an array where register data will be stored.
 * @param filter Bit mask to filter out specific registers.
 * @return true if read operation is successful, false otherwise.
 */
bool DRV_readRegister(uint8_t* data, uint8_t filter) {
    bool success = true;
    uint8_t* pData = data;

    for (int i = 0; i < DRV_REG_MAP_SIZE; i++) {
        if (!(filter & (1<<(DRV_REG_MAP_SIZE-i)))) {
            success = DRV_read(DRV_REG_MAP_SIZE-i, data);
            if (!success) break;
            data++;
        }
    }
    data = pData;

    return success;
}
