var searchData=
[
  ['drv8703_2ec_0',['drv8703.c',['../drv8703_8c.html',1,'']]],
  ['drv8703_2eh_1',['drv8703.h',['../drv8703_8h.html',1,'']]],
  ['drv_5finit_2',['DRV_init',['../drv8703_8c.html#ae1a5aacf397986967d30c41cd26c8de2',1,'DRV_init(void) :&#160;drv8703.c'],['../drv8703_8h.html#aacbd29ce1823b0224c877c38603f093a',1,'DRV_init(void):&#160;drv8703.c']]],
  ['drv_5fread_3',['DRV_read',['../drv8703_8c.html#a6e7e5754822fc7591f8e295e41a2f2e5',1,'DRV_read(uint8_t address, uint8_t* data) :&#160;drv8703.c'],['../drv8703_8h.html#a20282a1345478d9727afd2b154f8ec03',1,'DRV_read(uint8_t address, uint8_t* data):&#160;drv8703.c']]],
  ['drv_5freadregister_4',['DRV_readRegister',['../drv8703_8c.html#ac6ddea044fe8af3b4e7f293608332acf',1,'DRV_readRegister(uint8_t* data, uint8_t filter) :&#160;drv8703.c'],['../drv8703_8h.html#aa7b1c0486341a2c1df66628b3bb1255e',1,'DRV_readRegister(uint8_t* data, uint8_t filter):&#160;drv8703.c']]],
  ['drv_5fwrite_5',['DRV_write',['../drv8703_8c.html#a142990adb4744fc9b46c8fa254186949',1,'DRV_write(uint8_t address, uint8_t data) :&#160;drv8703.c'],['../drv8703_8h.html#ac5040b78f563159a60fefa0191052830',1,'DRV_write(uint8_t address, uint8_t data):&#160;drv8703.c']]],
  ['drv_5fwriteregister_6',['DRV_writeRegister',['../drv8703_8c.html#ae583d4ec0975376dce2bba83ecdcb199',1,'DRV_writeRegister(uint8_t* data, uint8_t filter) :&#160;drv8703.c'],['../drv8703_8h.html#a9d939b5c55d76ab91388896b786c667d',1,'DRV_writeRegister(uint8_t* data, uint8_t filter):&#160;drv8703.c']]]
];
